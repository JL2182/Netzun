for element in range(1, 10, 1):
    if element == 5:
        continue
    print(element)
