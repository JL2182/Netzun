# Caso 2 - Bucle infinito con condicional True - No recomendado
iterador = 0
while iterador != 10:
    print("Iteración: ", iterador)
    iterador += 1
