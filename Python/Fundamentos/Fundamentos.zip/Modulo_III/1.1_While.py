# Caso 1 - Bucle Finito
iterador = 0
while iterador < 10:
    print("Iteración: ", iterador)
    iterador += 1
