Element_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

for item in Element_list:
    print("Este es un elemnto de la lista", item)
