for element in range(1, 10):
    print(element)
    if element == 5:
        break
