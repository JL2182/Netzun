Texto = "Hola mundo"
for caracter in Texto:
    print(caracter)
