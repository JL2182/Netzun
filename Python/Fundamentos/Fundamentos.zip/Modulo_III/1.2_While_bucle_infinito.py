# Caso 2 - Bucle infinito con condicional True - No recomendado
iterador = 0
while True:
    print("Iteración: ", iterador)
    iterador += 1

# Recuerda que para detener un bucle infinito puedes usar la combinación de teclas Ctrl + C
# O puedes usar el comando de interrupción de Python: Ctrl + Z
# En caso de que estés utilizando un IDE o un editor de texto con consola integrada, puedes detener el bucle
