# Integer
entero = 25
print(entero)
print(type(entero))
