x = 100
y = 10

print("Valor de x = ", x)
print("Valor de y = ", y)

print("x + y = ", x + y)
print("x - y = ", x - y)
print("x * y = ", x * y)

# División flotante
print("x / y = ", x / y)

# División entera
print("x // y = ", x // y)

# Modulo
print("x % y = ", x % y)  # El modulo devuelve el residuo de la división
