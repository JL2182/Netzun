z = 40
z = z + 10
print(z)

variable_1, variable_2, variable_3 = 1, "Text", None
print(variable_1)
print(type(variable_1))

print(variable_2)
print(type(variable_2))

print(variable_3)
print(type(variable_3))
