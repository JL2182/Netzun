# Float
pi = 3.1416
print(pi)
print(type(pi))
