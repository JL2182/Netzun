# String
# Los valores String o de cadena de texto son una secuencia de caracteres.
texto = "Hola Mundo"
pi = "3.1416"
print(texto)
print(type(texto))
print(pi)
print(type(pi))
