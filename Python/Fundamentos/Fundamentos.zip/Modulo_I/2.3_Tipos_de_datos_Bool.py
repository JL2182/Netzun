# Boolean
# Los valores booleanos son True y False
# True = 1
# False = 0
# Ejemplo
bandera = True
print(bandera)
print(type(bandera))
print(False)
print(bool(1))
print(bool(0))
