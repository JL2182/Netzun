# 1. Creación de variables.
edad = 10
variable = 20.0

# 2. Solicitar variables por consola.
x = input("Ingresar valor por consola: ")

# 3. Imprimir valor de una variable en consola.
print(x)
print(edad)
print(variable)

# 4. Imprimir valores de variables en consola
print(x, edad, variable)
