x = 35
y = 30

print("x == y", x == y)  # Igual a
print("x != y", x != y)  # Diferente de
print("x > y", x > y)  # Mayor que
print("x < y", x < y)  # Menor que
print("x >= y", x >= y)  # Mayor o igual que
print("x <= y", x <= y)  # Menor o igual que
print("x is y", x is y)  # Identidad
print("x is not y", x is not y)  # No identidad
print("x in y", x in y)  # Pertenencia
print("x not in y", x not in y)  # No pertenencia

# También se pueden comparar cadenas de texto
