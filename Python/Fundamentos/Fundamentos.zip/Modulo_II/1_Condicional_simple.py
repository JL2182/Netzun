edad = int(input("Ingrese su edad: "))
if edad >= 18:
    print("Usted es mayor de edad.")
