edad = int(input("Ingrese su edad: "))
if edad >= 18:
    print("Usted es mayor de edad.")
else:
    print("Usted es menor de edad.")
# Compare this snippet from Modulo_II/2_Condicional_doble.py:
